<?php
require 'db_connection.php';

$id = $_GET['Sid'];

    $delete_query = "DELETE FROM studen1 WHERE id = $id";
    if ($conn->query($delete_query)) {
        header("Location: list_student.php?message=Student deleted successfully!");
    } else {
        echo "Error deleting student: " . $conn->error ;
    }
?>