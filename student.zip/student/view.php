<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/view_stu.css">

</head>

<body>
    <?php
    include 'header.php';
    require 'db_connection.php';
    ?>

    <?php
        $id=$_GET["Sid"];
        $q= "SELECT *FROM studen1 WHERE id='$id'";
        $stm= $conn->query($q);
        $user=$stm->fetch_assoc();

      ?>


    <div class="table_column">
        <h1>Student Information</h1>
        <table>
            <tr>
                <th>Profile</th>
                <td><img class="pro" src="uploads/<?= $user['image']?>"></td>
            </tr>
            <tr>
                <th>StudentId</th>
                <td><?= $user['id']?></td>
            </tr>
            <tr>
                <th>FullName</th>
                <td><?= $user['fullname']?></td>
            </tr>
            <tr>
                <th>Email</th>
                <td><?= $user['email']?></td>
            </tr>
            <tr>
                <th>Gender</th>
                <td><?= $user['gender']?></td>
            </tr>
            <tr>
                <th>Birthdata</th>
                <td><?= $user['birthdata']?></td>
            </tr>
            <tr>
                <th>Password</th>
                <td><?= $user['password']?></td>
            </tr>
            <tr>
                <th>Department</th>
                <td><?= $user['Department']?></td>
            </tr>
            <tr>
                <th>Action</th>
                <td><a href="list_student.php?id=<?= $user['id'] ?>"><button class="btn4">Back</button></a></td>
            </tr>
        </table>
    </div>
</body>

</html>