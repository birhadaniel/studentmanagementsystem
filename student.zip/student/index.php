<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Management System</title>
    <link rel="stylesheet" href="css/index.css">
</head>

<body>
    <div class="navitems"><span><img src="images/download.png" alt="">
            <h3>Student Management</h3>
        </span>
        <nav class="links">
            <li><a href="#">Home</a></li>
            <li><a href="#">About</a></li>
            <li><a href="#">Service</a></li>
        </nav>
    </div>
    <section>
        <div class="home_page">
            <h1>Welcome to the Student Management System</h1><a href="login.php"><button>GO Use</button></a>
        </div>
        <div class="image_page"><img src="images/hero-image.png" alt=""></div>
    </section>
</body>

</html>