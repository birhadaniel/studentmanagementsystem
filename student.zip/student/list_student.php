<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>List Students</title>
    <link rel="stylesheet" href="css/liststude.css">

</head>

<body>
    <?php
     include 'header.php';
     require 'db_connection.php';

   // Pagination setup
   $limit = 10; // Number of records per page
   $page = isset($_GET['page']) ? (int)$_GET['page'] : 1; // Current page number
   $offset = ($page - 1) * $limit; // Calculate offset
  
   $search=""; 
   $whereClause = "";
    if (isset($_POST['submit']) && !empty($_POST['search'])) {
       $search = $conn->real_escape_string($_POST['search']); 
       $whereClause = "WHERE fullname LIKE '%$search%'";
    }
 // Get the total number of students
    $total_students_query = $conn->query("SELECT COUNT(*) AS total FROM studen1 $whereClause");
    $total_students = $total_students_query->fetch_assoc()['total'];
    $total_pages = ceil($total_students / $limit); 

// Fetch students for the current page
     $students_query = $conn->query("SELECT * FROM studen1 $whereClause LIMIT $limit OFFSET $offset");
    
      ?>


    <div class="students-table">
        <h1>List Students</h1>
        <form action="" method="post">
            <input type="text" name="search" value="" placeholder="Search by username">
            <input type="submit" name="submit">
        </form>
        <table>
            <thead>
                <tr>
                    <th>SID</th>
                    <th>Full Name</th>
                    <th>Email</th>
                    <th>Gender</th>
                    <th colspan="3">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($students_query as  $row){?>

                <tr>
                    <td><?= $row['id']; ?></td>
                    <td><?= $row['fullname']; ?></td>
                    <td><?= $row['email']; ?></td>
                    <td><?= $row['gender']; ?></td>
                    <td><a href="view.php?Sid=<?= $row['id'] ?>"><button class="btn1">View</button></a></td>
                    <td> <a href="edit_student.php?Sid=<?= $row['id']; ?>"><button class="btn2">Edit</button></a></td>
                    <td><a href="delete_student.php?Sid=<?= $row['id']; ?>"><button class="btn3">Delete</button></a>
                    </td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
        <!-- Pagination Links -->
        <div class="pagination">
            <?php if ($page > 1) { ?>
            <a href="?page=<?php echo $page - 1; ?>" class="btn">Previous</a>
            <?php } ?>

            <?php for ($i = 1; $i <= $total_pages; $i++) { ?>
            <a href="?page=<?php echo $i; ?>" class="btn <?php echo $i == $page ? 'active' : ''; ?>">
                <?php echo $i; ?>
            </a>
            <?php } ?>

            <?php if ($page < $total_pages) { ?>
            <a href="?page=<?php echo $page + 1; ?>" class="btn">Next</a>
            <?php } ?>
        </div>
    </div>
    </div>
</body>

</html>