<?php
     include 'header.php';
     require 'db_connection.php';
     
     if (isset($_POST['AddStudent'])) {
         $fullname = $_POST['fullname'];
         $email = $_POST['email'];
         $password = $_POST['password'];
         $Department = $_POST['depart'];
         $sex = $_POST['sex'];
         $birthdata = $_POST['birthdata'];
         $encp=sha1($password);
             // Handle the image upload
         $image_name=$_FILES['image']['name'];
         $tempname=$_FILES['image']['tmp_name'];
      
         
            // Generate a unique filename
         $image_ext = strtolower(pathinfo($image_name, PATHINFO_EXTENSION));
         $newimage = round(microtime(true)) . '.' . $image_ext;
         $uploadpath = "./uploads/" . $newimage;
         
         if(move_uploaded_file($tempname, $uploadpath)){
           
             $sql = "INSERT INTO studen1 (fullname, email, gender, birthdata, password, Department,image)
                       VALUES ('$fullname', '$email', '$sex', '$birthdata', '$encp', '$Department','$newimage')";
             $stmt=$conn->prepare($sql);
             
             if ($stmt->execute()) {
                 header("Location:home.php");
                 exit();
                } else {
                    echo "Error: ".$sql ."<br>". $conn->error ;
                }
         }
         
            
        }
         ?>