-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 31, 2025 at 06:37 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `student_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `studen1`
--

CREATE TABLE `studen1` (
  `id` int(11) NOT NULL,
  `fullname` varchar(60) NOT NULL,
  `email` varchar(60) NOT NULL,
  `gender` char(1) NOT NULL,
  `birthdata` date NOT NULL,
  `password` text NOT NULL,
  `Department` varchar(50) NOT NULL,
  `image` varchar(150) NOT NULL,
  `create_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `studen1`
--

INSERT INTO `studen1` (`id`, `fullname`, `email`, `gender`, `birthdata`, `password`, `Department`, `image`, `create_date`) VALUES
(11, 'Hana', 'hana@gmail.com', 'M', '2003-05-10', '', 'CS', '1738321643.png', '2025-01-31 11:07:22'),
(12, 'Gemechu', 'geme@gmail.com', 'M', '2004-08-25', '03fee21f8d3676859bfe21ebd835cad4d5b1d8e0', 'Electrical Engineering', '1738321727.png', '2025-01-31 11:08:47'),
(13, 'Melat', 'melat@gmail.com', 'F', '2008-05-17', '03fee21f8d3676859bfe21ebd835cad4d5b1d8e0', 'Computer Science', '1738321811.png', '2025-01-31 11:10:11'),
(14, 'Hiwet', 'hiwet@gmail.com', 'F', '2004-05-21', 'db2a2d0a3c9992fa8b47f205df8c997ef90e1e5d', 'Software Engineering', '1738321915.png', '2025-01-31 11:11:54'),
(15, 'Mulugeta', 'mule@gmail.com', 'M', '2013-10-18', '03fee21f8d3676859bfe21ebd835cad4d5b1d8e0', 'Software Engineering', '1738321981.png', '2025-01-31 11:13:01'),
(16, 'Dagimawit', 'gagi@gmail.com', 'F', '2010-05-27', '04fa4c958c065ac6f929582b175cb3702a4deeb9', 'Computer Science', '1738322071.png', '2025-01-31 11:14:31'),
(17, 'Hojiwak', 'hoji@gmail.com', 'M', '2014-06-20', '03fee21f8d3676859bfe21ebd835cad4d5b1d8e0', 'Mechanical Engineering', '1738322132.png', '2025-01-31 11:15:32'),
(18, 'Abidi', 'abid@gmail.com', 'M', '2006-06-10', 'bc55df190b272ccf026708911809dce459cf5d7a', 'Electrical Engineering', '1738322252.png', '2025-01-31 11:17:31'),
(19, 'Kalkidan', 'qal@gmail.com', 'M', '2013-06-13', '', 'CS', '1738322387.png', '2025-01-31 11:19:47'),
(20, 'finan', 'fina@gmail.com', 'F', '2006-01-12', '68f6c1d28ef34f255aa5c5d3158657f074f68175', 'Computer Science', '1738324545.png', '2025-01-31 11:55:44'),
(21, 'Daniel ', 'dani@gmail.com', 'M', '2005-06-18', '03fee21f8d3676859bfe21ebd835cad4d5b1d8e0', 'Electrical Engineering', '1738326466.jpg', '2025-01-31 12:27:46'),
(22, 'Ashenafi', 'ashu@gmail.com', 'M', '2016-06-17', '03fee21f8d3676859bfe21ebd835cad4d5b1d8e0', 'Computer Science', '1738333619.png', '2025-01-31 14:26:58'),
(23, 'segni', 'segin@gmail.com', 'M', '2010-10-14', 'cf8b2de17870e13a72609f247ddf6ef117f96a9f', 'Computer Science', '1738341391.png', '2025-01-31 16:36:30'),
(24, 'Chala ', 'chala@gmail.com', 'M', '1988-01-31', '7c222fb2927d828af22f592134e8932480637c0d', 'Computer Science', '1738343812.jpg', '2025-01-31 17:16:51');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(100) NOT NULL,
  `create_data` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `user_name`, `password`, `name`, `create_data`) VALUES
(1, 'daniboy', '25d55ad283aa400af464c76d713c07ad', 'Daniel Birhanu', '2025-01-29 20:51:13'),
(2, 'napi', '81dc9bdb52d04dc20036dbd8313ed055', 'Napi', '2025-01-31 17:09:12');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `studen1`
--
ALTER TABLE `studen1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `studen1`
--
ALTER TABLE `studen1`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
