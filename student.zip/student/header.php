<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Management System</title>
    <link rel="stylesheet" href="css/header.css">
</head>

<body>
    <div class="navitems">
        <span>
            <img src="images/download.png" alt="">
            <h3>Student Management</h3>
        </span>
        <nav class="links">
            <li><a href="home.php">Dashboard</a></li>
            <li><a href="add_student.php">Add Student</a></li>
            <li><a href="list_student.php">List Student</a></li>
        </nav>
        <a href="index.php"><button>LogOut</button></a>
    </div>
</body>

</html>