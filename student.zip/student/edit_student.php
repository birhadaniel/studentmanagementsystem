<?php

include 'header.php';
require 'db_connection.php';


$id = $_GET['Sid'] ;

$result = $conn->query("SELECT * FROM studen1 WHERE id = $id");
$student = $result->fetch_assoc();

if (!$student) {
echo "<p class='error'>Student not found!</p>";
exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
$fullname =$_POST['fullname'];
$email = $_POST['email'];
$password = $_POST['password'];
$depart = $_POST['depart'];
$sex = $_POST['sex'];
$birthdata = $_POST['birthdata'];

$update_query = "UPDATE studen1 SET fullname='$fullname', email='$email', gender='$sex', birthdata='$birthdata',
password='$password', Department='$depart' WHERE id = $id";

if ($conn->query($update_query)) {
header("Location:list_student.php");
exit();
}
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Student</title>
    <link rel="stylesheet" href="css/addstudent.css">
    <style>
    body {
        background: linear-gradient(to right, #36d1dc, #74ebd5);
    }
    </style>
</head>

<body>
    <section class="form">
        <div class="student_form">
            <h1>Edit Student</h1>
            <form action="" method="POST">
                <div class="input_row">
                    <label for="fullname">Full Name</label>
                    <input type="text" name="fullname" value="<?= $student['fullname']; ?>" required>
                </div>
                <div class="input_row">
                    <label for="email">Email</label>
                    <input type="email" name="email" value="<?= $student['email']; ?>" required>
                </div>
                <div class="input_row">
                    <label for="sex">Gender</label>
                    <select name="sex" value="<?= $student['sex']; ?>">
                        <option value="M">Male</option>
                        <option value="F">Female</option>
                    </select>
                </div>
                <div class="input_row">
                    <label for="birthdata">birthdata</label>
                    <input type="date" name="birthdata" value="<?= $student['birthdata']; ?>">
                </div>
                <div class="input_row">
                    <label for="password">Password</label>
                    <input type="password" name="Password" value="<?= $student['password']; ?>">
                </div>
                <div class="input_row">
                    <label for="depart">Department</label>
                    <select name="depart" value="<?= $student['depart']; ?>">
                        <option value="CS">Computer Science</option>
                        <option value="SE">Software Engineering</option>
                        <option value="IS">Information Science</option>
                        <option value="ME">Mechanical Engineering</option>
                        <option value="EE">Electrical Engineering</option>
                    </select>
                </div>
                <button type="submit" class="btn">Update Student</button>
            </form>
        </div>
    </section>
</body>

</html>