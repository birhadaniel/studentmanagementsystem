<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Student</title>
    <link rel="stylesheet" href="css/addstudent.css">
    <style>
    body {
        background: linear-gradient(to right, #74ebd5, #acb6e5);
    }
    </style>
</head>

<body>

    <section class="form">
        <div class="student_form">
            <h1>Add New Student</h1>
            <form action="add_check.php" method="POST" enctype="multipart/form-data">
                <div class="input_row">
                    <label for="">Full Name</label>
                    <input type="text" id="" name="fullname" placeholder="full name" required>
                </div>
                <div class="input_row">
                    <label for="">Email</label>
                    <input type="email" id="" name="email" placeholder="email" required>
                </div>
                <div class="input_row">
                    <label for="">Gender</label>
                    <select name="sex" required>
                        <option value="M">Male</option>
                        <option value="F">Female</option>
                    </select>
                </div>
                <div class="input_row">
                    <label for="">birthdata</label>
                    <input type="date" name="birthdata" required>
                </div>
                <div class="input_row">
                    <label for="">Password</label>
                    <input type="password" name="password" placeholder="Password" required>
                </div>
                <div class="input_row">
                    <label for="">Department</label>
                    <select name="depart" required>
                        <option value="Computer Science">Computer Science</option>
                        <option value="Software Engineering">Software Engineering</option>
                        <option value="Information Science">Information Science</option>
                        <option value="Mechanical Engineering">Mechanical Engineering</option>
                        <option value="Electrical Engineering">Electrical Engineering</option>
                    </select>
                </div>
                <div class="input_row">
                    <label for="">Student Image</label>
                    <input type="file" name="image" placeholder="" required>
                </div>
                <button type="submit" name="AddStudent" class=" btn">Add Student</button>
            </form>
        </div>
    </section>
    </div>
</body>

</html>