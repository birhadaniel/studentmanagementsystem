<?php
include 'header.php';
include 'db_connection.php';


$result = $conn->query("SELECT COUNT(*) AS total_student FROM studen1");
if ($result) {
    $data = $result->fetch_assoc();
    $total_students = $data['total_student'];
} else {
    $total_students = 0;
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Management Dashboard</title>
    <link rel="stylesheet" href="css/home.css">

</head>

<body>
    <div class="container">
        <h1> Student Management System</h1>
        <p>Manage student records efficiently with this system.</p>

        <!-- Display Total Number of Students -->
        <div class="stats">
            <h2>Total Students: <?php echo $total_students; ?></h2>
        </div>

        <!-- Navigation Links -->
        <div class="home_links">
            <a href="add_student.php" class="btn">Add Student</a>
            <a href="list_student.php" class="btn">List Student</a>
            <!-- <a href="search_students.php" class="btn">Search Students</a> -->
        </div>
    </div>

</body>

</html>